
public interface WorkerInterface {
	
	// bulunduğu konuma belirtilen binayı yapar
	void build( Building b) throws AgeOfEmpiresException;

}
