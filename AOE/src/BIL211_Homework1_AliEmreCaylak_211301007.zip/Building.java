public class Building extends Item implements BuildingInterface{
    @Override
    public int getX() {
        return 0;
    }
    public void death(){

    }
    public void attack(int y, int x) throws AgeOfEmpiresException {
    }
    public void reattack(int y, int x) {
    }

    @Override
    public int getY() {
        return 0;
    }

    @Override
    public int getLifePoints() {
        return 0;
    }
    public int setLifePoints() {
        return 0;
    }

    @Override
    public String getSymbol() {
        return null;
    }
    public void setX(int x) {
    }

    public void setY(int y) {
    }
}
