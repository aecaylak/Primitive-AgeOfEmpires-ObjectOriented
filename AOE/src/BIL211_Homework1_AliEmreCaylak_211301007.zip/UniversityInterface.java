
public interface UniversityInterface {
	
	public void trainInfantry() throws AgeOfEmpiresException;
	
	public void trainCavalry() throws AgeOfEmpiresException;
	public void trainCatapult() throws AgeOfEmpiresException;
	

}
