public class AgeOfEmpiresException extends Exception
{

}
