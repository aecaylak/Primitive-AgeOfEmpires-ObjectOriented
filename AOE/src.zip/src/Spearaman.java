public class Spearaman extends Soldier{
}
