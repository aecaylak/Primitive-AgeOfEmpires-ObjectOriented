public class Game implements GameInterface{

    Player[] players;
    Map[][] map;

    public Game(int NumberOfPlayers){
        Player temp;
        players = new Player[NumberOfPlayers];

        for (int i=0;i<=NumberOfPlayers;i++){
            temp = new Player();
            players[i] = temp;
        }
    }
    @Override
    public Player getPlayer(int x) {
        return null;
    }

    @Override
    public Map getMap() {
        return null;
    }


    @Override
    public void save_text(String filename) {

    }

    @Override
    public void save_binary(String filename) {

    }
}
