public class Soldier extends Human{
}
