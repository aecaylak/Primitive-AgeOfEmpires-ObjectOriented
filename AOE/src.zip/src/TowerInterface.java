
public interface TowerInterface {
	
	// (x,y) koordinatlarındaki nesneye saldırabliyorsa saldırır, saldıramazsa AgeOfEmpires Exception'ı atar
	void attack(int x, int y);

}
