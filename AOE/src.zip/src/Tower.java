public class Tower extends Building implements TowerInterface{
}
