public class MainBuilding extends Building{
}
