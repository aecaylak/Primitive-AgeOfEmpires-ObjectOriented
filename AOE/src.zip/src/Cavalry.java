public class Cavalry extends Soldier{
}
