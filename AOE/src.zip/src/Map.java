public class Map implements MapInterface{

}
