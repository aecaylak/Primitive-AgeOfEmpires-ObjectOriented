public class Player implements PlayerInterface{
}
