public class Swordman extends Soldier{
}
