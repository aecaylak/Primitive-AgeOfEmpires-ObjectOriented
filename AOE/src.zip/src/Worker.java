public class Worker extends Human implements WorkerInterface{
}
