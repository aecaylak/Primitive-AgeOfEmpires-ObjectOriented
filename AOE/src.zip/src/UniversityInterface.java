
public interface UniversityInterface {
	
	public void trainInfantry();
	
	public void trainCavalry();
	public void trainCatapult();
	

}
