public class Catapult extends Soldier{
}
