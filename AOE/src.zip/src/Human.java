public class Human extends Item implements HumanInterface{

}
