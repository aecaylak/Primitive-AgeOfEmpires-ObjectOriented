public class University extends Building implements UniversityInterface{
}
