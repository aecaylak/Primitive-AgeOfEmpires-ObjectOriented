public class Archer extends Soldier{
}
